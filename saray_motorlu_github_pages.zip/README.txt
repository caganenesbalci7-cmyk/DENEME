SARAY MOTORLU - GITHUB PAGES

1) GitHub'da yeni repository oluştur.
2) Bu ZIP'teki index.html ve .nojekyll dosyalarını repository'nin köküne yükle.
3) Settings > Pages bölümüne gir.
4) Source: Deploy from a branch.
5) Branch: main / (root) seç ve Save.
6) GitHub'ın verdiği github.io adresini telefonda aç.

Bu sürüm önce erişim testi içindir.
